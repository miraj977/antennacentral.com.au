<section class="cta cta_style2" style="background: <?php echo get_field('cta_background_color',"option");?>">
<div class="container">
	<div class="row">
	<div class="col-md-12">
	<div class="cta_text" data-aos="fade-up">
		<h4 class="demiBold"><?php echo get_field('call_to_action_content',"option");?></h4></div>
	</div>	
	</div></div>
</section>