<div class="menu-half-only-menu"> <span class="modal-close"><img src="<?php echo get_stylesheet_directory_uri();?>/images/close_icon_grey.svg" ?></span>
  <?php
  wp_nav_menu( array(
    'theme_location' => 'menu-1',
    'menu' => 'Full screen menu',
  ) );
  ?>
  
</div>
