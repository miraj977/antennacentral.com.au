<?php echo do_shortcode("[hero-slider-fullScreen]"); ?>
